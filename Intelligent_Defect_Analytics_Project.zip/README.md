# Intelligent Defect Lifecycle Analytics & QA Dashboard

This project automates parsing JIRA exports, storing structured defect lifecycle data in SQL Server, and building Power BI dashboards to visualize key QA metrics.

## Quickstart

1. Prepare JIRA export (CSV or JSON).
2. Clean data:
   python jira_parser.py --input path/to/jira_export.csv --out clean_jira_defects.csv
3. Load to SQL Server:
   python etl/load_to_sql.py --csv clean_jira_defects.csv --server <SERVER> --database <DB> --trusted True
4. Open Power BI Desktop and connect to the `defects` table.

## Notes
- Adjust mapping in `jira_parser.py` for custom JIRA fields.
- Ensure ODBC Driver 17 for SQL Server is installed on the machine running ETL.
