# Power BI Dashboard - Defect Lifecycle Analytics

## Data source
Connect Power BI Desktop to your SQL Server database and import the `defects` table.

## Suggested visuals
- Line chart: Defects opened vs closed over time (created date, resolved date)
- Bar chart: Defects by priority
- KPI cards: Avg time to resolve, Open defects count, Reopened count
- Heatmap: Defects by component vs priority
- Table: Recent defects with status and assignee

## Recommended DAX measures

-- Open defects count
OpenDefects = CALCULATE(COUNTROWS(defects), FILTER(defects, defects[is_open] = 1))

-- Average time to resolve (days)
AvgResolveDays = AVERAGE(defects[time_to_resolve_days])

-- Median resolve days
MedianResolveDays = MEDIAN(defects[time_to_resolve_days])

-- SLA breach (percent > X days, e.g., 7)
SLA_Breached = 
VAR total = COUNTROWS(defects)
VAR breached = CALCULATE(COUNTROWS(defects), FILTER(defects, defects[time_to_resolve_days] > 7))
RETURN DIVIDE(breached, total, 0)
